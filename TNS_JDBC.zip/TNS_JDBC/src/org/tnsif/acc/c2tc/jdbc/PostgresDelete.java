package org.tnsif.acc.c2tc.jdbc;

public class PostgresDelete {

}
